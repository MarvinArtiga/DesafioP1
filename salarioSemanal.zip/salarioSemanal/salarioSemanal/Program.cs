﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Salida_Entrada_Pantalla
{
    class Program
    {
        static void Main(string[] args)
        {
            // Este progrmam fue hecho por Marvin Artiga 
            //10/02/2023
            //Salario semanal

                
            Console.WindowHeight = 25; // alto de la ventana
            Console.WindowWidth = 70; //ancho de la ventana
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Title=("SalarioSemanal");
            Console.Clear();

            //declaracion de variables



            int hours = 30;
            double worked,pay,total;
            Console.WriteLine("\t\t\n----------------------------Calcular el salario de una semana de un obrero------------------------- ");
            //Reglas
            Console.WriteLine("\n*La jornada semanala es de 30 horas ");
            Console.WriteLine("*Si se pasa de 30 horas trabajadas se pagaran horas extra ");
            Console.WriteLine("Cada hora extra se paga con el 125%");
            Console.ForegroundColor= ConsoleColor.Black;

            Console.Write("\t\n ¿Cuanto te pagan por hora?: ");
            pay = double.Parse(Console.ReadLine());
            Console.Write("\t\n¿Cuantas horas trabajaste?: ");
            worked =double.Parse(Console.ReadLine());
            Console.Write("\n");
            



            //calculo
           // total = pay * hours;
          total=0;
            if (worked <=hours)
            {
                //Pantalla de presentacion
                Console.Write("\t");
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("*************************************************************************");
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine("\t Tu jornada semanal fue de: \'"+worked+" horas\' Por lo tanto tu sueldo es de:");
                total = pay * worked;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\t\n");
                Console.WriteLine("\t\t\'"+total+"$\'");
                Console.Write("\t");
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("*************************************************************************");
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine("\n");
                Console.Write("\t");
                Console.WriteLine("--> Fin del Programa");
            } 
              else
                {
                double extraHours =worked-30;
                total = pay * 30;
                double extraPay =30*pay+extraHours*pay*1.25 ;
                Console.Write("\t");
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("*******************************************************************************");
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine("\t Tu jornada semanal fue de: \'" + worked +" horas\' Por lo tanto se te pagaran horas extra.");

                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("\t\n");
                Console.WriteLine("\t tu sueldo es de: \'" + total + "$\' +  "+extraHours+" horas extra");
                Console.Write("\t");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\t En total te quedaria un pago de: \'"+extraPay+"$\' sigue asi campeon ;)");
                Console.Write("\t");
                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("*******************************************************************************");
                Console.ForegroundColor = ConsoleColor.Black;
                Console.BackgroundColor = ConsoleColor.White;
                Console.WriteLine("\n");
                Console.Write("\t");
                Console.WriteLine("--> Fin del Programa");

            }
            




            Console.ReadKey();

        }
    }
}